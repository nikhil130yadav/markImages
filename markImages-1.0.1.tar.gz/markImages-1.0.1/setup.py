#!/usr/bin/env python
# coding: utf-8

# In[1]:


from distutils.core import setup

setup(
    name = 'markImages',
    version = '1.0.1',
    py_modules = ['markImages'],
    author = 'nikhil130yadav',
    author_email = 'nikhil.nikhil2008@gmail.com',
    url = 'https://github.com/nikhil130yadav',
    description = 'A library to mark the images/objects in other large Image'
)


# In[ ]:




